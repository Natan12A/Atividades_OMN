public class Modelo {
    private int[] vetor;

    public Modelo() {
        vetor = new int[]{54, 26, 93, 17, 77, 31, 44, 55, 20, 65};
    }

    public int buscarElemento(int elemento) {
        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] == elemento) {
                return i;
            }
        }
        return -1;
    }
}
