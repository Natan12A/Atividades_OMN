public class Controlador {
    private Modelo modelo;
    private Visualizacao visualizacao;

    public Controlador(Modelo modelo, Visualizacao visualizacao) {
        this.modelo = modelo;
        this.visualizacao = visualizacao;
    }

    public void buscarElemento(int elemento) {
        int resultado = modelo.buscarElemento(elemento);
        visualizacao.mostrarResultado(resultado);
    }
}
