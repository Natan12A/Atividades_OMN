
public class buscaSequencial {
	public static void main (String[]args) {
		int []vetor={54,26,93,17,77,31,44,55,20,65};
		int elementeParaEncontrar=93;
		int resultado=buscaSequencial (vetor, elementeParaEncontrar);
		if(resultado!=-1) {
			System.out.println("Elemento encontrado no indice"+resultado);
		}else{
			System.out.println("Elemento não encontrado");
		}
	}
	public static int buscaSequencial(int []vetor, int elemento) {
		for(int i=0;i<vetor.length;i++) {
			if(vetor[i]==elemento) {
				return i;
			}
		}
		return - i;
	}

}
