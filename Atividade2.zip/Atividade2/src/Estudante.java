import javax.swing.JOptionPane;

// Camada de Modelagem
class Estudante {
    String nome;
    int idade;

    public Estudante(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
}


