// Camada de Visão

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        FilaDeEstudantes fila = new FilaDeEstudantes(5); // Capacidade da fila é 5

        while (true) {
            String opcao = JOptionPane.showInputDialog("Escolha uma opção:\n" + "1. Adicionar Estudante\n" + "2. Remover Estudante\n" + "3. Sair");

            switch (opcao) {
                case "1":
                    String nome = JOptionPane.showInputDialog("Digite o nome do estudante:");
                    int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a idade do estudante:"));
                    fila.adicionarEstudante(new Estudante(nome, idade));
                    break;
                case "2":
                    Estudante estudanteRemovido = fila.removerEstudante();
                    if (estudanteRemovido != null) {
                        JOptionPane.showMessageDialog(null, "Estudante removido: " + estudanteRemovido.nome);
                    }
                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, "Saindo...");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida. Por favor, escolha novamente.");
                    break;
            }
        }
    }
}