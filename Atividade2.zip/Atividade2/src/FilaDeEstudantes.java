// Camada de Negócio

import javax.swing.JOptionPane;

class FilaDeEstudantes {
    private Estudante[] fila;
    private int tamanho;
    private int capacidade;
    private int inicio;
    private int fim;

    public FilaDeEstudantes(int capacidade) {
        this.capacidade = capacidade;
        fila = new Estudante[capacidade];
        tamanho = 0;
        inicio = 0;
        fim = -1;
    }

    public void adicionarEstudante(Estudante estudante) {
        if (tamanho < capacidade) {
            fim = (fim + 1) % capacidade;
            fila[fim] = estudante;
            tamanho++;
            JOptionPane.showMessageDialog(null, "Estudante adicionado à fila.");
        } else {
            JOptionPane.showMessageDialog(null, "A fila está cheia. Não é possível adicionar mais estudantes.");
        }
    }

    public Estudante removerEstudante() {
        if (tamanho > 0) {
            Estudante estudanteRemovido = fila[inicio];
            inicio = (inicio + 1) % capacidade;
            tamanho--;
            JOptionPane.showMessageDialog(null, "Estudante removido da fila.");
            return estudanteRemovido;
        } else {
            JOptionPane.showMessageDialog(null, "A fila está vazia. Não há estudantes para remover.");
            return null;
        }
    }
}
